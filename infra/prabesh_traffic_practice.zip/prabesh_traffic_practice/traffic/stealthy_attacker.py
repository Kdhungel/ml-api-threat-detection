"""低频模拟：使用合理样本、延长请求间隔；用于测试检测系统的不足。"""

import argparse
from .common import add_arguments, load_samples, run_scenario


def main():
    parser = add_arguments(argparse.ArgumentParser(description='低频模拟请求'))
    args = parser.parse_args()
    samples = load_samples()

    # 此示例使用真实数据中的不同样本，因此输入看起来更像医院查询。
    vectors = [samples[30 + i].tolist() for i in range(args.count)]

    # 离线虚拟时间间隔 120 秒；不会真的消耗 10 分钟。
    virtual_times = [i * 120 for i in range(args.count)]
    run_scenario(args, caller_id='Attacker_Stealth', scenario='stealthy_attacker',
                 feature_vectors=vectors, relative_seconds=virtual_times)


if __name__ == '__main__':
    main()
