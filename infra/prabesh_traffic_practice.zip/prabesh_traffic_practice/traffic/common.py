"""四种流量脚本共用的工具：数据准备、模拟发送、真实请求、结果记录。"""

import argparse
import csv
import json
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
from sklearn.datasets import load_breast_cancer

# 离线默认模式：不会发送任何 HTTP 请求，也不会产生 GCP 费用。
# 真实模式只能手动传入 --live，并且必须使用自己有权测试的 API。
MAX_REQUESTS = 10
MAX_RPS = 1.0  # 上限：平均每秒最多一条请求（单线程、顺序发送）


def add_arguments(parser: argparse.ArgumentParser):
    """让四个入口脚本使用相同的参数。"""
    parser.add_argument('--count', type=int, default=5, help='本次模拟请求数，1 到 10')
    parser.add_argument('--live', action='store_true', help='明确选择真实 HTTP 请求；默认仅离线')
    parser.add_argument('--api-url', default='', help='团队授权的完整 /predict URL（真实模式必填）')
    parser.add_argument('--interval', type=float, default=None, help='两次请求之间的秒数；真实模式至少 1 秒')
    parser.add_argument('--output', default='results', help='输出 CSV/JSONL 的目录')
    parser.add_argument('--seed', type=int, default=42, help='固定随机种子，方便复现实验')
    return parser


def validate_args(args):
    """提前检查参数，防止误操作或产生失控流量。"""
    if not 1 <= args.count <= MAX_REQUESTS:
        raise ValueError(f'--count 必须介于 1 和 {MAX_REQUESTS} 之间')
    if args.interval is not None and args.interval < 0:
        raise ValueError('--interval 不能为负数')
    if args.live:
        if not args.api_url.startswith('https://'):
            raise ValueError('真实模式必须提供以 https:// 开头的 --api-url')
        if not args.api_url.rstrip('/').endswith('/predict'):
            raise ValueError('真实模式的 URL 必须以 /predict 结尾')
        if args.interval is not None and args.interval < 1 / MAX_RPS:
            raise ValueError('真实模式必须每次请求至少间隔 1 秒')


def load_samples():
    """使用与 Ramya 教学练习一致的乳腺癌数据集（30 个特征）。"""
    dataset = load_breast_cancer()
    samples = dataset.data.astype(float)
    if samples.shape[1] != 30:
        raise ValueError('数据集不是 30 个特征，无法匹配团队 API')
    return samples


def log_paths(output, scenario):
    folder = Path(output)
    folder.mkdir(parents=True, exist_ok=True)
    return folder / f'{scenario}_requests.jsonl', folder / f'{scenario}_ground_truth.csv'


def run_scenario(args, *, caller_id, scenario, feature_vectors, relative_seconds):
    """执行通用模拟：离线只记录；真实模式向指定 API 顺序发送并保存响应。"""
    validate_args(args)
    vectors = list(feature_vectors)
    times = list(relative_seconds)
    if len(vectors) != args.count or len(times) != args.count:
        raise ValueError('输入列表长度必须等于 --count')

    requests_file, truth_file = log_paths(args.output, scenario)
    start = datetime.now(timezone.utc)
    records = []
    truth = []

    # 真实请求使用 requests；离线模式完全不会导入或调用它。
    if args.live:
        import requests
        token = os.environ.get('PREDICTION_API_KEY', '')
        # API Key 的实际验证方法必须以 Ramya 的正式设计为准；不要把密钥写入代码或日志。
        headers = {'X-API-Key': token} if token else {}
        # 若 Cloud Run 要求 IAM 身份令牌，还需要另行配置身份验证；仅填 URL 不一定能访问。
    else:
        requests = None
        headers = {}

    for i, (features, offset) in enumerate(zip(vectors, times), start=1):
        vector = np.asarray(features, dtype=float).tolist()
        if len(vector) != 30 or not np.isfinite(vector).all():
            raise ValueError('输入必须是 30 个有限数值')

        # 攻击者/医院发送给 API 的数据：不包含 scenario 标签。
        payload = {'caller_id': caller_id, 'features': vector}
        event_time = (datetime.now(timezone.utc) if args.live
                      else start + timedelta(seconds=float(offset)))

        status, response = None, None
        if args.live:
            try:
                r = requests.post(args.api_url, json=payload, headers=headers, timeout=10)
                status = r.status_code
                try:
                    response = r.json()
                except ValueError:
                    response = {'message': r.text[:200]}
            except requests.RequestException as exc:
                response = {'error': type(exc).__name__}
        else:
            # 离线只演示“请求会长什么样”，不伪造模型预测。
            response = {'simulation': 'offline', 'note': '未调用 API，故无预测结果'}

        records.append({
            'timestamp': event_time.isoformat(),
            'caller_id': caller_id,
            'features': vector,
            'http_status': status,
            'api_response': response,
        })
        # Ground Truth 单独存放，检测方不应该直接用此列当作真实流量特征。
        truth.append({'timestamp': event_time.isoformat(), 'caller_id': caller_id,
                      'scenario': scenario, 'request_index': i})
        print(f'[{scenario}] {i}/{args.count} 状态={status if status is not None else "离线"}')

        if args.live and i < args.count:
            time.sleep(max(1 / MAX_RPS, args.interval if args.interval is not None else 1.0))

    with requests_file.open('w', encoding='utf-8') as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False) + '\n')
    with truth_file.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['timestamp', 'caller_id', 'scenario', 'request_index'])
        writer.writeheader()
        writer.writerows(truth)
    print(f'请求记录：{requests_file}')
    print(f'真实标签：{truth_file}')
    print('真实请求数：' + str(args.count if args.live else 0))
