"""正常医院：从真实数据集中选取不同样本，以规律的低频模式模拟请求。"""

import argparse
from .common import add_arguments, load_samples, run_scenario


def main():
    parser = add_arguments(argparse.ArgumentParser(description='正常医院流量模拟'))
    args = parser.parse_args()
    samples = load_samples()

    # 每次使用不同的患者样本；按数据集中固定顺序选择，便于复现。
    vectors = [samples[i].tolist() for i in range(args.count)]

    # 这些时间是“离线模拟时间”，不会真的等待 60 秒。
    # 真实模式为了便于演示，实际等待时间由 common.py 管控。
    virtual_times = [i * 60 for i in range(args.count)]
    run_scenario(args, caller_id='Hospital_A', scenario='normal_hospital',
                 feature_vectors=vectors, relative_seconds=virtual_times)


if __name__ == '__main__':
    main()
