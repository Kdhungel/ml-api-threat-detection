"""集中式查询模拟：短时间、不同输入；只用于本地分析或授权的小规模测试。"""

import argparse
import numpy as np
from .common import add_arguments, load_samples, run_scenario


def main():
    parser = add_arguments(argparse.ArgumentParser(description='集中式模型查询模拟'))
    args = parser.parse_args()
    samples = load_samples()
    rng = np.random.default_rng(args.seed)

    # 用每个特征在现有数据中的最小值和最大值生成随机输入。
    # 注意：各特征分别取范围值，不保证生成的组合具有真实医学意义。
    low = samples.min(axis=0)
    high = samples.max(axis=0)
    vectors = [rng.uniform(low, high).tolist() for _ in range(args.count)]

    # 离线“虚拟时间”相邻 1 秒，展示高密度查询的特征。
    # 实际在线模式依然强制不超过每秒 1 条请求。
    virtual_times = list(range(args.count))
    run_scenario(args, caller_id='Attacker_Fast', scenario='smash_and_grab',
                 feature_vectors=vectors, relative_seconds=virtual_times)


if __name__ == '__main__':
    main()
