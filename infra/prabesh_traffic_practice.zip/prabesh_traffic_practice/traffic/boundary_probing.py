"""边界探测示例：围绕一个基准样本小幅修改单一特征。"""

import argparse
from .common import add_arguments, load_samples, run_scenario


def main():
    parser = add_arguments(argparse.ArgumentParser(description='局部扰动查询模拟'))
    args = parser.parse_args()
    samples = load_samples()

    base = samples[10].copy()
    # 按第 1 个特征在数据集中的标准差设置扰动量，避免固定 0.01 过大或过小。
    step = float(samples[:, 0].std()) * 0.01
    vectors = []
    for i in range(args.count):
        changed = base.copy()
        changed[0] += i * step   # 其他 29 个特征保持不变
        vectors.append(changed.tolist())

    # 间隔五秒的虚拟记录，用来研究连续查询的相似度。
    virtual_times = [i * 5 for i in range(args.count)]
    run_scenario(args, caller_id='Attacker_Boundary', scenario='boundary_probing',
                 feature_vectors=vectors, relative_seconds=virtual_times)


if __name__ == '__main__':
    main()
