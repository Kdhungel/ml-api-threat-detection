# Prabesh Traffic Simulation — Group 10 中文练习包

这个练习包面向 Jia 学习 Prabesh 的职责：在 **Ramya 已经提供的 Prediction API** 前面，用 Python 模拟不同请求行为。**Prabesh 不需要 Flask**；Flask 属于 Ramya 的服务端代码。

## 不产生 GCP 费用的默认模式

1. 用 Google Colab、电脑终端或 Cloud Shell（仅文件演示）打开本项目。
2. 安装依赖：`python -m pip install -r requirements.txt`
3. 在项目根目录执行：`python run_all.py`
4. 查看 `results/` 中的 `.jsonl` 请求数据与 `_ground_truth.csv` 真实标签。

可以单独运行：

```bash
python -m traffic.normal_hospital --count 5
python -m traffic.smash_and_grab --count 5
python -m traffic.boundary_probing --count 5
python -m traffic.stealthy_attacker --count 5
```

**这些命令默认不会发出 HTTP 请求**。只会制造带虚拟时间的 JSONL 数据，不会伪造模型响应。一次运行 `run_all.py` 会得到 20 条本地记录。

## 文件用途

- `traffic/common.py`：所有脚本公用的参数、30 个特征、请求发送、输出、限速和结果处理。
- `traffic/normal_hospital.py`：不同真实样本，低频请求。
- `traffic/smash_and_grab.py`：在观察范围内随机生成不同输入，密集的虚拟时间。
- `traffic/boundary_probing.py`：相同样本中仅改变一个特征。
- `traffic/stealthy_attacker.py`：真实样本，低频虚拟时间。
- `run_all.py`：依次运行四个**离线**方案。
- `results/*_requests.jsonl`：模拟请求详情，不含 Ground Truth。
- `results/*_ground_truth.csv`：仅供实验评估使用的请求真实身份，不应当直接作为检测特征。

## 脚本与云平台怎么连接？

只有在 **Ramya 已部署并明确授权测试的 API** 上，才可手工选择 `--live`：

```bash
python -m traffic.normal_hospital --count 3 --live --api-url 'https://YOUR-AUTHORIZED-SERVICE.run.app/predict' --interval 2
```

真实模式不会自动运行，单次最多 10 条，单线程顺序发送，每次至少间隔 1 秒，每次 HTTP 超时 10 秒。此示例不是压力测试工具。`caller_id` 是请求中的演示身份字段，不是经过认证的身份。若 Ramya 的 API 设计是 `X-API-Key`，可通过环境变量 `PREDICTION_API_KEY` 提供密钥；如果使用 Cloud Run IAM 身份令牌，则需要按团队认证配置另做适配，不能把 API Key 假装成 IAM Token。

**特别提醒：** `--live` 会产生真实 API 请求和潜在云费用；因此学习时不添加它即可。不要对第三方或未经授权的系统运行。正式实验需由组长批准身份、频率、次数和预算。

## 关键区别

- **Ramya**：使用 Flask + 训练好的 ML 模型实现 `/predict`，部署在 Cloud Run。
- **Prabesh**：使用 Python 构造输入、控制请求时间、用 `requests.post()` 调用该 API。
- **Jawad**：把 Ramya 的服务端日志导入 BigQuery。
- **Kritish**：根据请求频率和输入相似度等特征判定异常；`ground_truth.csv` 仅用于检验规则。

## 重要边界

离线脚本的 `timestamp` 是虚拟时间，不能当作真实 Cloud Logging 的记录；离线记录不包含真实模型预测。模拟数据集来自 `sklearn.datasets.load_breast_cancer()`，不是患者医疗数据。医疗预测只是课程练习，不用于真实临床诊断。真实部署需和 Ramya 对齐 JSON 字段、认证方式和日志 Schema。
