"""一键运行四类离线模拟：仅生成文件，不访问 GCP 或任何 HTTP 服务。"""

import subprocess
import sys

SCRIPTS = [
    'traffic.normal_hospital',
    'traffic.smash_and_grab',
    'traffic.boundary_probing',
    'traffic.stealthy_attacker',
]

for module in SCRIPTS:
    print('\n==============================')
    print('运行：', module)
    subprocess.run([sys.executable, '-m', module, '--count', '5'], check=True)

print('\n所有离线模拟已结束。共生成 20 条请求记录，真实 HTTP 请求为 0。')
