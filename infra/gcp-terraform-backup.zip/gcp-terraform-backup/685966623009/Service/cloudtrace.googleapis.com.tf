resource "google_project_service" "cloudtrace_googleapis_com" {
  project = "685966623009"
  service = "cloudtrace.googleapis.com"
}
# terraform import google_project_service.cloudtrace_googleapis_com 685966623009/cloudtrace.googleapis.com
