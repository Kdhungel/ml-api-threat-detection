resource "google_project_service" "iap_googleapis_com" {
  project = "685966623009"
  service = "iap.googleapis.com"
}
# terraform import google_project_service.iap_googleapis_com 685966623009/iap.googleapis.com
