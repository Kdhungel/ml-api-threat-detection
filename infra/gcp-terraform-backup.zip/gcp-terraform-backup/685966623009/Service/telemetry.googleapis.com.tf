resource "google_project_service" "telemetry_googleapis_com" {
  project = "685966623009"
  service = "telemetry.googleapis.com"
}
# terraform import google_project_service.telemetry_googleapis_com 685966623009/telemetry.googleapis.com
