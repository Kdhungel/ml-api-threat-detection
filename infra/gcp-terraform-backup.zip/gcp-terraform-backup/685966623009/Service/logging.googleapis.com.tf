resource "google_project_service" "logging_googleapis_com" {
  project = "685966623009"
  service = "logging.googleapis.com"
}
# terraform import google_project_service.logging_googleapis_com 685966623009/logging.googleapis.com
