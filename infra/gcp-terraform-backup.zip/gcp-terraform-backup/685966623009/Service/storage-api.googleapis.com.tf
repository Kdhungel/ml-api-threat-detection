resource "google_project_service" "storage_api_googleapis_com" {
  project = "685966623009"
  service = "storage-api.googleapis.com"
}
# terraform import google_project_service.storage_api_googleapis_com 685966623009/storage-api.googleapis.com
