resource "google_project_service" "agentidentity_googleapis_com" {
  project = "685966623009"
  service = "agentidentity.googleapis.com"
}
# terraform import google_project_service.agentidentity_googleapis_com 685966623009/agentidentity.googleapis.com
