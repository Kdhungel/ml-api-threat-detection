resource "google_project_service" "datastore_googleapis_com" {
  project = "685966623009"
  service = "datastore.googleapis.com"
}
# terraform import google_project_service.datastore_googleapis_com 685966623009/datastore.googleapis.com
