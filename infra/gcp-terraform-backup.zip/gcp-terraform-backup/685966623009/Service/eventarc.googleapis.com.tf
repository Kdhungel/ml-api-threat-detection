resource "google_project_service" "eventarc_googleapis_com" {
  project = "685966623009"
  service = "eventarc.googleapis.com"
}
# terraform import google_project_service.eventarc_googleapis_com 685966623009/eventarc.googleapis.com
