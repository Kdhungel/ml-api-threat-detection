resource "google_project_service" "networksecurity_googleapis_com" {
  project = "685966623009"
  service = "networksecurity.googleapis.com"
}
# terraform import google_project_service.networksecurity_googleapis_com 685966623009/networksecurity.googleapis.com
