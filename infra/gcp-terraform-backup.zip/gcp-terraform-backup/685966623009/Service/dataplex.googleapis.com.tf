resource "google_project_service" "dataplex_googleapis_com" {
  project = "685966623009"
  service = "dataplex.googleapis.com"
}
# terraform import google_project_service.dataplex_googleapis_com 685966623009/dataplex.googleapis.com
