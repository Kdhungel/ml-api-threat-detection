resource "google_project_service" "containerregistry_googleapis_com" {
  project = "685966623009"
  service = "containerregistry.googleapis.com"
}
# terraform import google_project_service.containerregistry_googleapis_com 685966623009/containerregistry.googleapis.com
