resource "google_project_service" "serviceusage_googleapis_com" {
  project = "685966623009"
  service = "serviceusage.googleapis.com"
}
# terraform import google_project_service.serviceusage_googleapis_com 685966623009/serviceusage.googleapis.com
