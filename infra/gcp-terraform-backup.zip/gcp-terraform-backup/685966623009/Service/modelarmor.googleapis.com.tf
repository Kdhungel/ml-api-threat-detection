resource "google_project_service" "modelarmor_googleapis_com" {
  project = "685966623009"
  service = "modelarmor.googleapis.com"
}
# terraform import google_project_service.modelarmor_googleapis_com 685966623009/modelarmor.googleapis.com
