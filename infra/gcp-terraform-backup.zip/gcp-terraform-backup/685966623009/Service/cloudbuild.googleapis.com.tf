resource "google_project_service" "cloudbuild_googleapis_com" {
  project = "685966623009"
  service = "cloudbuild.googleapis.com"
}
# terraform import google_project_service.cloudbuild_googleapis_com 685966623009/cloudbuild.googleapis.com
