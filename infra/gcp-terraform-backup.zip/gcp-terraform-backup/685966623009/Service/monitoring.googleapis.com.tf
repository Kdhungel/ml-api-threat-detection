resource "google_project_service" "monitoring_googleapis_com" {
  project = "685966623009"
  service = "monitoring.googleapis.com"
}
# terraform import google_project_service.monitoring_googleapis_com 685966623009/monitoring.googleapis.com
