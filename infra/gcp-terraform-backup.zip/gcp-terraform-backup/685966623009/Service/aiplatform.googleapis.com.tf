resource "google_project_service" "aiplatform_googleapis_com" {
  project = "685966623009"
  service = "aiplatform.googleapis.com"
}
# terraform import google_project_service.aiplatform_googleapis_com 685966623009/aiplatform.googleapis.com
