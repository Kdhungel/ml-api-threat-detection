resource "google_project_service" "bigquerydatapolicy_googleapis_com" {
  project = "685966623009"
  service = "bigquerydatapolicy.googleapis.com"
}
# terraform import google_project_service.bigquerydatapolicy_googleapis_com 685966623009/bigquerydatapolicy.googleapis.com
