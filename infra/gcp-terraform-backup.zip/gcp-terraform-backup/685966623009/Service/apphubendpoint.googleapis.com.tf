resource "google_project_service" "apphubendpoint_googleapis_com" {
  project = "685966623009"
  service = "apphubendpoint.googleapis.com"
}
# terraform import google_project_service.apphubendpoint_googleapis_com 685966623009/apphubendpoint.googleapis.com
