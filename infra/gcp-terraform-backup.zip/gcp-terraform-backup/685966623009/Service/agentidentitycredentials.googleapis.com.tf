resource "google_project_service" "agentidentitycredentials_googleapis_com" {
  project = "685966623009"
  service = "agentidentitycredentials.googleapis.com"
}
# terraform import google_project_service.agentidentitycredentials_googleapis_com 685966623009/agentidentitycredentials.googleapis.com
