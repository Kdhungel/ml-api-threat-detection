resource "google_project_service" "texttospeech_googleapis_com" {
  project = "685966623009"
  service = "texttospeech.googleapis.com"
}
# terraform import google_project_service.texttospeech_googleapis_com 685966623009/texttospeech.googleapis.com
