resource "google_project_service" "bigquery_googleapis_com" {
  project = "685966623009"
  service = "bigquery.googleapis.com"
}
# terraform import google_project_service.bigquery_googleapis_com 685966623009/bigquery.googleapis.com
