resource "google_project_service" "cloudfunctions_googleapis_com" {
  project = "685966623009"
  service = "cloudfunctions.googleapis.com"
}
# terraform import google_project_service.cloudfunctions_googleapis_com 685966623009/cloudfunctions.googleapis.com
