resource "google_project_service" "saasservicemgmt_googleapis_com" {
  project = "685966623009"
  service = "saasservicemgmt.googleapis.com"
}
# terraform import google_project_service.saasservicemgmt_googleapis_com 685966623009/saasservicemgmt.googleapis.com
