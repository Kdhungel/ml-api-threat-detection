resource "google_project_service" "bigquerydatatransfer_googleapis_com" {
  project = "685966623009"
  service = "bigquerydatatransfer.googleapis.com"
}
# terraform import google_project_service.bigquerydatatransfer_googleapis_com 685966623009/bigquerydatatransfer.googleapis.com
