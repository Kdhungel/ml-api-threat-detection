resource "google_project_service" "notebooks_googleapis_com" {
  project = "685966623009"
  service = "notebooks.googleapis.com"
}
# terraform import google_project_service.notebooks_googleapis_com 685966623009/notebooks.googleapis.com
