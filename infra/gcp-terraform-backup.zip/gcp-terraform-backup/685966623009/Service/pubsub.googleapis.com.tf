resource "google_project_service" "pubsub_googleapis_com" {
  project = "685966623009"
  service = "pubsub.googleapis.com"
}
# terraform import google_project_service.pubsub_googleapis_com 685966623009/pubsub.googleapis.com
