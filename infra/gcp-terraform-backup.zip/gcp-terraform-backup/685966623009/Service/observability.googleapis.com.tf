resource "google_project_service" "observability_googleapis_com" {
  project = "685966623009"
  service = "observability.googleapis.com"
}
# terraform import google_project_service.observability_googleapis_com 685966623009/observability.googleapis.com
