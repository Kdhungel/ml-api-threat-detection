resource "google_project_service" "servicemanagement_googleapis_com" {
  project = "685966623009"
  service = "servicemanagement.googleapis.com"
}
# terraform import google_project_service.servicemanagement_googleapis_com 685966623009/servicemanagement.googleapis.com
