resource "google_project_service" "securitycenter_googleapis_com" {
  project = "685966623009"
  service = "securitycenter.googleapis.com"
}
# terraform import google_project_service.securitycenter_googleapis_com 685966623009/securitycenter.googleapis.com
