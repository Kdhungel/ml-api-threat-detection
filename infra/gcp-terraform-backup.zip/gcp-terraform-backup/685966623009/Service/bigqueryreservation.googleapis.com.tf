resource "google_project_service" "bigqueryreservation_googleapis_com" {
  project = "685966623009"
  service = "bigqueryreservation.googleapis.com"
}
# terraform import google_project_service.bigqueryreservation_googleapis_com 685966623009/bigqueryreservation.googleapis.com
