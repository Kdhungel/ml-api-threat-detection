resource "google_project_service" "networkservices_googleapis_com" {
  project = "685966623009"
  service = "networkservices.googleapis.com"
}
# terraform import google_project_service.networkservices_googleapis_com 685966623009/networkservices.googleapis.com
