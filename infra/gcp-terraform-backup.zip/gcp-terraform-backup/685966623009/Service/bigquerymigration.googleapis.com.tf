resource "google_project_service" "bigquerymigration_googleapis_com" {
  project = "685966623009"
  service = "bigquerymigration.googleapis.com"
}
# terraform import google_project_service.bigquerymigration_googleapis_com 685966623009/bigquerymigration.googleapis.com
