resource "google_project_service" "edgecache_googleapis_com" {
  project = "685966623009"
  service = "edgecache.googleapis.com"
}
# terraform import google_project_service.edgecache_googleapis_com 685966623009/edgecache.googleapis.com
