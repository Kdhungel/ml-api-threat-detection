resource "google_project_service" "analyticshub_googleapis_com" {
  project = "685966623009"
  service = "analyticshub.googleapis.com"
}
# terraform import google_project_service.analyticshub_googleapis_com 685966623009/analyticshub.googleapis.com
