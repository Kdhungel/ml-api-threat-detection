resource "google_project_service" "secretmanager_googleapis_com" {
  project = "685966623009"
  service = "secretmanager.googleapis.com"
}
# terraform import google_project_service.secretmanager_googleapis_com 685966623009/secretmanager.googleapis.com
