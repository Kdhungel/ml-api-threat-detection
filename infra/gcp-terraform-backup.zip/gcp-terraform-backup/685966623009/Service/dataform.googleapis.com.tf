resource "google_project_service" "dataform_googleapis_com" {
  project = "685966623009"
  service = "dataform.googleapis.com"
}
# terraform import google_project_service.dataform_googleapis_com 685966623009/dataform.googleapis.com
