resource "google_project_service" "iam_googleapis_com" {
  project = "685966623009"
  service = "iam.googleapis.com"
}
# terraform import google_project_service.iam_googleapis_com 685966623009/iam.googleapis.com
