resource "google_project_service" "securitycentermanagement_googleapis_com" {
  project = "685966623009"
  service = "securitycentermanagement.googleapis.com"
}
# terraform import google_project_service.securitycentermanagement_googleapis_com 685966623009/securitycentermanagement.googleapis.com
