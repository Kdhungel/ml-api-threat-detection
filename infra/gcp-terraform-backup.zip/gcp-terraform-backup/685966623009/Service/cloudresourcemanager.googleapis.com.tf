resource "google_project_service" "cloudresourcemanager_googleapis_com" {
  project = "685966623009"
  service = "cloudresourcemanager.googleapis.com"
}
# terraform import google_project_service.cloudresourcemanager_googleapis_com 685966623009/cloudresourcemanager.googleapis.com
