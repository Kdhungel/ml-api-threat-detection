resource "google_project_service" "bigqueryconnection_googleapis_com" {
  project = "685966623009"
  service = "bigqueryconnection.googleapis.com"
}
# terraform import google_project_service.bigqueryconnection_googleapis_com 685966623009/bigqueryconnection.googleapis.com
