resource "google_project_service" "cloudapiregistry_googleapis_com" {
  project = "685966623009"
  service = "cloudapiregistry.googleapis.com"
}
# terraform import google_project_service.cloudapiregistry_googleapis_com 685966623009/cloudapiregistry.googleapis.com
