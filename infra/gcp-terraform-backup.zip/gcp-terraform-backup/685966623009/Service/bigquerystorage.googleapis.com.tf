resource "google_project_service" "bigquerystorage_googleapis_com" {
  project = "685966623009"
  service = "bigquerystorage.googleapis.com"
}
# terraform import google_project_service.bigquerystorage_googleapis_com 685966623009/bigquerystorage.googleapis.com
