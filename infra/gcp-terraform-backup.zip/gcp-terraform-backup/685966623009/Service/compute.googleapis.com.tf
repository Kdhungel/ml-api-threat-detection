resource "google_project_service" "compute_googleapis_com" {
  project = "685966623009"
  service = "compute.googleapis.com"
}
# terraform import google_project_service.compute_googleapis_com 685966623009/compute.googleapis.com
