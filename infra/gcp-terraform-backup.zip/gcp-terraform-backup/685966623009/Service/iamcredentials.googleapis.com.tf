resource "google_project_service" "iamcredentials_googleapis_com" {
  project = "685966623009"
  service = "iamcredentials.googleapis.com"
}
# terraform import google_project_service.iamcredentials_googleapis_com 685966623009/iamcredentials.googleapis.com
