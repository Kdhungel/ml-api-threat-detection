resource "google_project_service" "apptopology_googleapis_com" {
  project = "685966623009"
  service = "apptopology.googleapis.com"
}
# terraform import google_project_service.apptopology_googleapis_com 685966623009/apptopology.googleapis.com
