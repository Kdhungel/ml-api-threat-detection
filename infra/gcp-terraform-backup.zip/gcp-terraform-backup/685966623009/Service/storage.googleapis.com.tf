resource "google_project_service" "storage_googleapis_com" {
  project = "685966623009"
  service = "storage.googleapis.com"
}
# terraform import google_project_service.storage_googleapis_com 685966623009/storage.googleapis.com
