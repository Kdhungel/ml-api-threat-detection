resource "google_project_service" "backupdr_googleapis_com" {
  project = "685966623009"
  service = "backupdr.googleapis.com"
}
# terraform import google_project_service.backupdr_googleapis_com 685966623009/backupdr.googleapis.com
