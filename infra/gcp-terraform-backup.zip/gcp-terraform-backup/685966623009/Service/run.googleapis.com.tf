resource "google_project_service" "run_googleapis_com" {
  project = "685966623009"
  service = "run.googleapis.com"
}
# terraform import google_project_service.run_googleapis_com 685966623009/run.googleapis.com
