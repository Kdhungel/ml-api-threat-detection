resource "google_project_service" "cloudapis_googleapis_com" {
  project = "685966623009"
  service = "cloudapis.googleapis.com"
}
# terraform import google_project_service.cloudapis_googleapis_com 685966623009/cloudapis.googleapis.com
