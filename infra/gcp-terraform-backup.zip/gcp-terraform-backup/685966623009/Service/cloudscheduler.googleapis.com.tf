resource "google_project_service" "cloudscheduler_googleapis_com" {
  project = "685966623009"
  service = "cloudscheduler.googleapis.com"
}
# terraform import google_project_service.cloudscheduler_googleapis_com 685966623009/cloudscheduler.googleapis.com
