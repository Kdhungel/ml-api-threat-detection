resource "google_project_service" "cloudasset_googleapis_com" {
  project = "685966623009"
  service = "cloudasset.googleapis.com"
}
# terraform import google_project_service.cloudasset_googleapis_com 685966623009/cloudasset.googleapis.com
