resource "google_project_service" "oslogin_googleapis_com" {
  project = "685966623009"
  service = "oslogin.googleapis.com"
}
# terraform import google_project_service.oslogin_googleapis_com 685966623009/oslogin.googleapis.com
