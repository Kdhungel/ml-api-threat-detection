resource "google_project_service" "artifactregistry_googleapis_com" {
  project = "685966623009"
  service = "artifactregistry.googleapis.com"
}
# terraform import google_project_service.artifactregistry_googleapis_com 685966623009/artifactregistry.googleapis.com
