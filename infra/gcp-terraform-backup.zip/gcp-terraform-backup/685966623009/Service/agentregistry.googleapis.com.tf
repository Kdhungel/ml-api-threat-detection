resource "google_project_service" "agentregistry_googleapis_com" {
  project = "685966623009"
  service = "agentregistry.googleapis.com"
}
# terraform import google_project_service.agentregistry_googleapis_com 685966623009/agentregistry.googleapis.com
