resource "google_project_service" "apphub_googleapis_com" {
  project = "685966623009"
  service = "apphub.googleapis.com"
}
# terraform import google_project_service.apphub_googleapis_com 685966623009/apphub.googleapis.com
