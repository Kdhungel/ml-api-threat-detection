resource "google_project" "cloud_computing_project_510701" {
  auto_create_network = true

  labels = {
    managed-by-cnrm = "true"
  }

  name       = "mlsec-cloud-computing-project"
  org_id     = "329589314771"
  project_id = "cloud-computing-project-510701"
}
# terraform import google_project.cloud_computing_project_510701 projects/cloud-computing-project-510701
