resource "google_compute_disk" "mlworkbench_data_workspace" {
  labels = {
    consumer-project-id     = "cloud-computing-project-510701"
    consumer-project-number = "685966623009"
    managed-by-cnrm         = "true"
    notebooks-product       = "workbench-instances"
    resource-name           = "mlworkbench"
  }

  name                      = "mlworkbench-data-workspace"
  physical_block_size_bytes = 4096
  project                   = "cloud-computing-project-510701"
  size                      = 100
  type                      = "pd-balanced"
  zone                      = "northamerica-northeast2-a"
}
# terraform import google_compute_disk.mlworkbench_data_workspace projects/cloud-computing-project-510701/zones/northamerica-northeast2-a/disks/mlworkbench-data-workspace
