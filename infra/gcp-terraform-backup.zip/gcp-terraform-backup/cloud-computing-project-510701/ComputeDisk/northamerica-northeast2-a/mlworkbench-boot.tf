resource "google_compute_disk" "mlworkbench_boot" {
  guest_os_features {
    type = "GVNIC"
  }

  guest_os_features {
    type = "SEV_CAPABLE"
  }

  guest_os_features {
    type = "SEV_LIVE_MIGRATABLE"
  }

  guest_os_features {
    type = "SEV_LIVE_MIGRATABLE_V2"
  }

  guest_os_features {
    type = "SEV_SNP_CAPABLE"
  }

  guest_os_features {
    type = "SUSPEND_SAFE_FPR"
  }

  guest_os_features {
    type = "UEFI_COMPATIBLE"
  }

  guest_os_features {
    type = "VIRTIO_SCSI_MULTIQUEUE"
  }

  image = "https://www.googleapis.com/compute/beta/projects/cloud-notebooks-managed/global/images/workbench-2603-20261105-2130-rc0"

  labels = {
    consumer-project-id     = "cloud-computing-project-510701"
    consumer-project-number = "685966623009"
    managed-by-cnrm         = "true"
    notebooks-product       = "workbench-instances"
    resource-name           = "mlworkbench"
  }

  licenses                  = ["https://www.googleapis.com/compute/v1/projects/debian-cloud/global/licenses/debian-12-bookworm", "https://www.googleapis.com/compute/v1/projects/click-to-deploy-images/global/licenses/c2d-dl-platform-workbench-instances-2603"]
  name                      = "mlworkbench-boot"
  physical_block_size_bytes = 4096
  project                   = "cloud-computing-project-510701"
  size                      = 150
  type                      = "pd-balanced"
  zone                      = "northamerica-northeast2-a"
}
# terraform import google_compute_disk.mlworkbench_boot projects/cloud-computing-project-510701/zones/northamerica-northeast2-a/disks/mlworkbench-boot
