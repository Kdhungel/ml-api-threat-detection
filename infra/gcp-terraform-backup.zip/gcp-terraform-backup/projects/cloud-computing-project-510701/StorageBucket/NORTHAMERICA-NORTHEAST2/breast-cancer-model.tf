resource "google_storage_bucket" "breast_cancer_model" {
  force_destroy = false

  labels = {
    managed-by-cnrm = "true"
  }

  location                 = "NORTHAMERICA-NORTHEAST2"
  name                     = "breast-cancer-model"
  project                  = "cloud-computing-project-510701"
  public_access_prevention = "inherited"

  soft_delete_policy {
    retention_duration_seconds = 604800
  }

  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
}
# terraform import google_storage_bucket.breast_cancer_model breast-cancer-model
