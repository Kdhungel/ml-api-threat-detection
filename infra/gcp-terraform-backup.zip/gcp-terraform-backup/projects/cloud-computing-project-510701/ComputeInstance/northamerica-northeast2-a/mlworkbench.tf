resource "google_compute_instance" "mlworkbench" {
  attached_disk {
    device_name = "data-workspace"
    mode        = "READ_WRITE"
    source      = "https://www.googleapis.com/compute/v1/projects/cloud-computing-project-510701/zones/northamerica-northeast2-a/disks/mlworkbench-data-workspace"
  }

  boot_disk {
    auto_delete = true
    device_name = "boot"

    initialize_params {
      image = "https://www.googleapis.com/compute/beta/projects/cloud-notebooks-managed/global/images/workbench-2603-20261105-2130-rc0"

      labels = {
        consumer-project-id     = "cloud-computing-project-510701"
        consumer-project-number = "685966623009"
        notebooks-product       = "workbench-instances"
        resource-name           = "mlworkbench"
      }

      size = 150
      type = "pd-balanced"
    }

    mode   = "READ_WRITE"
    source = "https://www.googleapis.com/compute/v1/projects/cloud-computing-project-510701/zones/northamerica-northeast2-a/disks/mlworkbench-boot"
  }

  labels = {
    consumer-project-id     = "cloud-computing-project-510701"
    consumer-project-number = "685966623009"
    managed-by-cnrm         = "true"
    notebooks-product       = "workbench-instances"
    resource-name           = "mlworkbench"
  }

  machine_type = "e2-standard-4"

  metadata = {
    disable-mixer              = "true"
    disable-swap-binaries      = "true"
    enable-antigravity         = "true"
    enable-guest-attributes    = "TRUE"
    enable-jupyterlab4         = "true"
    enable-oslogin             = "TRUE"
    idle-timeout-seconds       = "10800"
    instance-region            = "northamerica-northeast2"
    new-proxy-agent-enabled    = "true"
    notebooks-api              = "PROD"
    notebooks-api-version      = "v2"
    proxy-backend-id           = "6f5d5e8866cbb282"
    proxy-mode                 = "service_account"
    proxy-registration-url     = "https://northamerica-northeast2.notebooks.cloud.google.com/tun/m/4592f092208ecc84946b8f8f8016274df1b36a14"
    proxy-url                  = "6f5d5e8866cbb282-dot-northamerica-northeast2.notebooks.googleusercontent.com"
    report-dns-resolution      = "true"
    report-event-health        = "true"
    report-event-url           = "https://notebooks.googleapis.com/v2/projects/cloud-computing-project-510701/locations/northamerica-northeast2-a/instances/mlworkbench:reportInfoSystem"
    resource-url               = "https://notebooks.googleapis.com/v2/projects/cloud-computing-project-510701/locations/northamerica-northeast2-a/instances/mlworkbench"
    serial-port-logging-enable = "true"
    shutdown-script            = "/opt/deeplearning/bin/shutdown_script.sh"
    version                    = "20261105-2130-rc0"
  }

  name = "mlworkbench"

  network_interface {
    access_config {
      network_tier = "PREMIUM"
    }

    network            = "https://www.googleapis.com/compute/v1/projects/cloud-computing-project-510701/global/networks/default"
    network_ip         = "10.188.0.2"
    stack_type         = "IPV4_ONLY"
    subnetwork         = "https://www.googleapis.com/compute/v1/projects/cloud-computing-project-510701/regions/northamerica-northeast2/subnetworks/default"
    subnetwork_project = "cloud-computing-project-510701"
  }

  project = "cloud-computing-project-510701"

  reservation_affinity {
    type = "NO_RESERVATION"
  }

  scheduling {
    automatic_restart   = true
    on_host_maintenance = "MIGRATE"
    provisioning_model  = "STANDARD"
  }

  service_account {
    email  = "685966623009-compute@developer.gserviceaccount.com"
    scopes = ["https://www.googleapis.com/auth/cloud-platform", "https://www.googleapis.com/auth/userinfo.email"]
  }

  shielded_instance_config {
    enable_integrity_monitoring = true
    enable_vtpm                 = true
  }

  tags = ["deeplearning-vm", "notebook-instance"]
  zone = "northamerica-northeast2-a"
}
# terraform import google_compute_instance.mlworkbench projects/cloud-computing-project-510701/zones/northamerica-northeast2-a/instances/mlworkbench
