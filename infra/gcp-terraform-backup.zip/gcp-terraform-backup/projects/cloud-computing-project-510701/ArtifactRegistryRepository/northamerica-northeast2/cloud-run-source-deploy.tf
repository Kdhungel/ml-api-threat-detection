resource "google_artifact_registry_repository" "cloud_run_source_deploy" {
  description = "Cloud Run Source Deployments"
  format      = "DOCKER"

  labels = {
    managed-by-cnrm = "true"
  }

  location      = "northamerica-northeast2"
  mode          = "STANDARD_REPOSITORY"
  project       = "cloud-computing-project-510701"
  repository_id = "cloud-run-source-deploy"
}
# terraform import google_artifact_registry_repository.cloud_run_source_deploy projects/cloud-computing-project-510701/locations/northamerica-northeast2/repositories/cloud-run-source-deploy
