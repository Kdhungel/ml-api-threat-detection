resource "google_service_account" "685966623009_compute" {
  account_id   = "685966623009-compute"
  display_name = "Default compute service account"
  project      = "cloud-computing-project-510701"
}
# terraform import google_service_account.685966623009_compute projects/cloud-computing-project-510701/serviceAccounts/685966623009-compute@cloud-computing-project-510701.iam.gserviceaccount.com
