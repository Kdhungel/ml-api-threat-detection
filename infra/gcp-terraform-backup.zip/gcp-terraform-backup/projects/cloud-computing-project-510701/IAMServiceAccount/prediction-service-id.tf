resource "google_service_account" "prediction_service_id" {
  account_id   = "prediction-service-id"
  description  = "working for prediction service"
  display_name = "sa-prediction-api"
  project      = "cloud-computing-project-510701"
}
# terraform import google_service_account.prediction_service_id projects/cloud-computing-project-510701/serviceAccounts/prediction-service-id@cloud-computing-project-510701.iam.gserviceaccount.com
